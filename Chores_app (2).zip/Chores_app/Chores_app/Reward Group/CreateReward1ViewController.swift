//
//  CreateReward1ViewController.swift
//  Chores_app
//
//  Created by  on 4/19/21.
//

import UIKit

class CreateReward1ViewController: UIViewController {
    
    @IBOutlet var rewardName: UITextField!
    @IBOutlet var rewardDate: UITextField!
    @IBOutlet var rewardEarned: UITextField!
    
    var rName = ""
    var rDate = ""
    var rEarn = ""
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func createReward(_ sender: Any) {
        self.rName = rewardName.text!
        self.rDate = rewardDate.text!
        self.rEarn = rewardEarned.text!
        performSegue(withIdentifier: "reward", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var vc = segue.destination as! RewardsVC1
        vc.rewardName1 = self.rName
        vc.rewardDate2 = self.rDate
        vc.rewardEarn3 = self.rEarn
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
