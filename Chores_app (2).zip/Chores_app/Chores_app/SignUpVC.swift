//
//  SignUpVC.swift
//  Chores_app
//
//  Created by TROY johnson on 2021-04-09.
//

import UIKit

class SignUpVC: UIViewController{
    
    var user:[Login]? = nil
  
    @IBOutlet var signUp: UIButton!
    @IBOutlet var username1: UITextField!
    @IBOutlet var password: UITextField!
    @IBOutlet var password2: UITextField!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        user = CoredDataHandler.fetchObject()
    }
    
    
    
    @IBAction func Signup(_ sender: Any) {
        let userName = username1.text;
        let pass = password.text;
        let pass1 = password2.text;
        
        
        if(userName!.isEmpty || pass!.isEmpty || pass1!.isEmpty)
        {
            
             displayMyAlertMessage(userMessage: "all Fields are required");
            return;
        }
        
        
        
        if(userName != user![0].username! && pass != user![0].password! && pass1 != user![0].password1!)
        {
            let vc = (storyboard?.instantiateViewController(withIdentifier: "SigninVC") as? SigninVC)
        if CoredDataHandler.saveObject(username: userName!, password: pass!, password1:pass1!){
            navigationController?.pushViewController(vc!, animated: true)
            displayMyAlertMessage(userMessage: "\(String(describing: user![0].username!))  you have successfully registered");
    }
    
        }
        
        
        
        if(userName == user![0].username! && pass == user![0].password!  && pass1 == user![0].password1!)
        {
            let vc = (storyboard?.instantiateViewController(withIdentifier: "SigninVC") as? SigninVC)
            navigationController?.pushViewController(vc!, animated: true)
            displayMyAlertMessage(userMessage: "\(String(describing: user![0].username!))  you have already registered Sign in please")
        }
        
        
        else if(pass != pass1)
        {
            
           displayMyAlertMessage(userMessage: "Passwords do not match");
            return;
        }
    }
    
    
    func displayMyAlertMessage(userMessage:String)
    {
        let myAlert = UIAlertController(title: "Alert", message:userMessage, preferredStyle: UIAlertController.Style.alert);
        
    let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler:nil);
        
    myAlert.addAction(okAction);
    
        self.present(myAlert, animated: true, completion:nil);
   }
}
    


