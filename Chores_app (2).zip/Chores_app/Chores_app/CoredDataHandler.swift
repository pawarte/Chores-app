//
//  CoredDataHandler.swift
//  Chores_app
//
//  Created by TROY johnson on 2021-04-13.
//

import UIKit
import CoreData

class CoredDataHandler: NSObject {
    
    private class func getContext()-> NSManagedObjectContext{
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        return appDelegate.persistentContainer.viewContext
    }

    
    class func saveObject(username:String, password:String, password1:String)-> Bool{
        let context = getContext()
        let entity = NSEntityDescription.entity(forEntityName: "Login", in: context)
        let manageObject = NSManagedObject(entity: entity!, insertInto: context)
        
        manageObject.setValue(username, forKey: "username")
        manageObject.setValue(password, forKey: "password")
        manageObject.setValue(password1, forKey: "password1")
        //manageObject.setValue(rewardName, forKey: "rewardName")
        //manageObject.setValue(rewardDate, forKey: "rewardDate")
        //manageObject.setValue(rewardEarned, forKey: "rewardEarned")
        
        
        do{
            try context.save()
            return true
        }
        catch{
            return false
        }
        
    }
    
    class func fetchObject() -> [Login]? {
        let context = getContext()
        var user:[Login]? = nil
        do{
            user = try context.fetch(Login.fetchRequest())
            return user
        }
        catch
        {
          return user
        }
    }
}
