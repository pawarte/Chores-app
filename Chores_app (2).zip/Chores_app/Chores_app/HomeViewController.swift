//
//  HomeViewController.swift
//  Chores_app
//
//  Created by TROY johnson on 2021-04-09.
//

import UIKit

class HomeViewController: UIViewController {

    var user:[Login]? = nil
    
    
    @IBOutlet var userName: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        user = CoredDataHandler.fetchObject()
        //userName.text = user![0].password!
    }
    

 

}
