//
//  SigninVC.swift
//  Chores_app
//
//  Created by TROY johnson on 2021-04-09.
//

import UIKit
import FBSDKLoginKit

class SigninVC: UIViewController, LoginButtonDelegate{

    var user:[Login]? = nil
  
    @IBOutlet var username: UITextField!
    @IBOutlet var password: UITextField!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        user = CoredDataHandler.fetchObject()
    }
    
    
    @IBAction func Signin(_ sender: Any) {
        let uName = username.text;
    let pass = password.text;
    
    
    if(uName!.isEmpty || pass!.isEmpty)
    {
         displayMyAlertMessage(userMessage: "all Fields are required");
        return;
    }
    
        if(uName != user![0].username!  && pass != user![0].password!){
        displayMyAlertMessage(userMessage: "Incorrect password/ username try again or click to sign up");
    }

    if(uName == "" && pass == "")
    {
        if(uName == user![0].username!  && pass == user![0].password! ){
        let vc = (storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController)
            displayMyAlertMessage(userMessage: "\(String(describing: user![0].username!))you have successfully signed in");
        navigationController?.pushViewController(vc!, animated: true)
        }
}
    }
    


func displayMyAlertMessage(userMessage:String)
{
    let myAlert = UIAlertController(title: "Alert", message:userMessage, preferredStyle: UIAlertController.Style.alert);
    
let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler:nil);
    
myAlert.addAction(okAction);

    self.present(myAlert, animated: true, completion:nil);
}
    
    
    @IBAction func FBLogin(_ sender: Any) {
        user = CoredDataHandler.fetchObject()
        if let token = AccessToken.current,
           !token.isExpired{
            let token = token.tokenString
            
            let request = FBSDKLoginKit.GraphRequest(graphPath: "me",
                                                     parameters: ["fields": "email,name"],
                                                     tokenString: token,
                                                     version: nil,
                                                     httpMethod: .get)
            
            request.start(completionHandler: {connection, result, error in
                print("\(result)")
            })
            
        }
        else{
        let loginButton = FBLoginButton()
                loginButton.center = view.center
               loginButton.delegate = self
            loginButton.permissions = ["public_profile", "email"]
                view.addSubview(loginButton)
    }
    }
    
    
    func loginButton(_ loginButton: FBLoginButton, didCompleteWith result: LoginManagerLoginResult?, error: Error?) {
        let token = result?.token?.tokenString
        
        let request = FBSDKLoginKit.GraphRequest(graphPath: "me",
                                                 parameters: ["fields": "email,name"],
                                                 tokenString: token,
                                                 version: nil,
                                                 httpMethod: .get)
        
        request.start(completionHandler: {connection, result, error in
            print("\(result)")
        })
    }
    
    func loginButtonDidLogOut(_ loginButton: FBLoginButton) {
        
    }
    
}

    

